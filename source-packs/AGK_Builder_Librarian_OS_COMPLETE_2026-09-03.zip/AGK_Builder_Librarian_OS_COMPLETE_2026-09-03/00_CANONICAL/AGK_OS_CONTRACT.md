# AGK OS Contract — Canonical

Every existing and future AGK Operative System must implement the full contract below.

```text
OS = package
   + Nano Director
   + NanoTeam
   + profiles
   + ordered skills
   + deterministic programs
   + MCP/tool contracts
   + knowledge and memory scopes
   + provider routes
   + workflows
   + automations
   + evaluations
   + Discord control surface
   + doctor
   + rollback
   + recovery artifact
   + Librarian best advice from sourced domain works
   + Discord commands on the dedicated OS bot
```

## Definition of done

An OS is complete only when:
- every mandatory component exists;
- its contract is machine-readable;
- deterministic behavior has tests;
- declared tools pass live verification;
- eval thresholds pass;
- Discord command/readback works;
- doctor passes;
- rollback has been dry-run or verified against a fixture;
- a recovery artifact can reconstruct the OS without embedding secrets;
- a fresh session can execute its critical workflow;
- evidence is stored for the release.

## Dedicated Discord rule

Each OS owns a dedicated Discord bot and dedicated channel. The bot represents the Nano Director. A substantial unit of work runs in a mission thread. Agent-to-agent delegation creates or links a child mission/thread with typed context rather than spilling context into unrelated channels.

## Isolation rule

A client, organization, personal profile or mission may only access capabilities, memory and credentials explicitly granted to its scope. Cross-client memory or credential leakage is a release blocker.

## Research rule

A domain OS cannot reach release without a Librarian handoff based on real domain sources. The handoff extracts principles, not copyrighted text, and maps each selected insight to concrete OS components.
