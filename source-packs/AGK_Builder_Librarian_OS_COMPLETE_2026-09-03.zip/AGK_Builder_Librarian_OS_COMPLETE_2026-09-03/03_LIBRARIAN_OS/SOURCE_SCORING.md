# Source Scoring

Suggested 0–5 dimensions:
- mission relevance × 3;
- authority × 2;
- evidence strength × 2;
- originality/foundational value × 1;
- practical transferability × 2;
- source independence × 1;
- recency fitness × 1 (only important for recency-sensitive domains).

Do not let a numerical score override obvious domain judgment. Record the rationale.
