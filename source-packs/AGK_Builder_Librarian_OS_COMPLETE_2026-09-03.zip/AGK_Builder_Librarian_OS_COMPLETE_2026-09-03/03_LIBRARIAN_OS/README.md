# Librarian OS

Librarian OS is the research and synthesis OS that gives Builder domain best practices grounded in real works.

It is **not** a generic summarizer. Its output must be actionable for OS construction.

## Core command

```text
/book --deep --context "AGK, <mission>" <theme>
```

Optional modes:
- `--canonical`: prioritize foundational/canonical works;
- `--recent`: add current high-quality papers/docs where the domain changes quickly;
- `--contrarian`: include credible competing schools of thought;
- `--operator`: prioritize applied/operator works;
- `--bestseller`: editorial/pedagogy construction mode only; never claim sales-chart status unless verified.

## Required output

1. Domain framing.
2. Real source inventory with provenance.
3. Source quality scoring.
4. Principles matrix.
5. **15 best inputs** selected for this OS mission.
6. Tensions/contradictions between sources.
7. Missing evidence / uncertainty.
8. Mapping of each input into AGK components.
9. `14_BUILDER_HANDOFF.md`.

## Copyright boundary

Extract concepts and synthesize them. Do not reproduce protected chapters, long passages or derivative substitutes for the source.
