#!/usr/bin/env python3
import argparse, json, os, re, shutil, sys, zipfile, hashlib
from pathlib import Path

REQUIRED_DIRS = [
 '00_META','01_MASTER','02_OS_CATALOG','03_NANOTEAM','04_SKILLS','05_PROGRAMS','06_CAPABILITIES',
 '07_KNOWLEDGE','08_MEMORY','09_PROVIDER_ROUTES','10_WORKFLOWS','11_AUTOMATIONS','12_EVALS','13_DISCORD',
 '14_LIBRARIAN','15_DOCTOR','16_ROLLBACK','17_RECOVERY','18_EVIDENCE','19_DEPLOYMENT','20_GOVERNANCE'
]
REQUIRED_CONTRACT_KEYS = ['os_id','version','nano_director','nanoteam','profiles','ordered_skills','programs','tool_contracts','knowledge_scopes','memory_scopes','provider_routes','workflows','automations','evaluations','discord','doctor','rollback','recovery','librarian']

def slugify(s):
    s = s.lower().strip()
    s = re.sub(r'[^a-z0-9]+','-',s).strip('-')
    return s or 'new-os'

def write(p, text):
    p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text, encoding='utf-8')

def scaffold(args):
    slug = args.slug or slugify(args.name)
    root = Path(args.output).resolve()/slug
    if root.exists() and any(root.iterdir()):
        raise SystemExit(f'Refusing to overwrite non-empty {root}')
    for d in REQUIRED_DIRS: (root/d).mkdir(parents=True, exist_ok=True)
    manifest = {
      'schema_version':'1.0','os_id':slug,'name':args.name,'version':'0.1.0','type':'operative_system',
      'entrypoint':'01_MASTER/OS.md','contract':'CONTRACT.json','librarian_handoff':'14_LIBRARIAN/14_BUILDER_HANDOFF.md',
      'secret_policy':'references_only','dependencies':[],'capabilities':[],'checksums':{}
    }
    contract = {
      'schema_version':'1.0','os_id':slug,'version':'0.1.0','nano_director':f'{slug}-director','nanoteam':[],
      'profiles':[],'ordered_skills':[],'programs':[],'tool_contracts':[],'knowledge_scopes':[],'memory_scopes':[],
      'provider_routes':[],'workflows':[],'automations':[],'evaluations':[],'discord':{'mode':'dedicated','bot':'REQUIRED','channel':'REQUIRED','commands_file':'13_DISCORD/COMMANDS.yaml'},
      'doctor':{'required':True},'rollback':{'required':True},'recovery':{'required':True},
      'librarian':{'required':True,'theme':args.theme,'handoff':'14_LIBRARIAN/14_BUILDER_HANDOFF.md','minimum_selected_inputs':15}
    }
    write(root/'MANIFEST.json', json.dumps(manifest,indent=2)+'\n')
    write(root/'CONTRACT.json', json.dumps(contract,indent=2)+'\n')
    write(root/'01_MASTER/OS.md', f'# {args.name}\n\nTheme: {args.theme}\n\n## Mission\nTODO\n\n## Definition of success\nTODO\n')
    write(root/'14_LIBRARIAN/14_BUILDER_HANDOFF.md', '# 14_BUILDER_HANDOFF\n\nSTATUS: INCOMPLETE\n\nComplete a Librarian deep research run and provide exactly 15 selected inputs before release.\n')
    write(root/'13_DISCORD/COMMANDS.yaml', 'commands:\n  - name: mission\n  - name: status\n  - name: plan\n  - name: approve\n  - name: review\n  - name: doctor\n  - name: recover\n  - name: help\n')
    for d in REQUIRED_DIRS:
        readme=root/d/'README.md'
        if not readme.exists(): write(readme, f'# {d}\n\nTODO: complete this required OS component.\n')
    print(root)

def count_handoff_inputs(text):
    ids = set(re.findall(r'(?im)^###?\s+Input\s+(\d{1,2})\b', text))
    return len(ids)

def doctor_path(root):
    root=Path(root).resolve(); errors=[]; warnings=[]
    for d in REQUIRED_DIRS:
        if not (root/d).is_dir(): errors.append(f'missing directory: {d}')
    for f in ['MANIFEST.json','CONTRACT.json','01_MASTER/OS.md','14_LIBRARIAN/14_BUILDER_HANDOFF.md']:
        if not (root/f).is_file(): errors.append(f'missing file: {f}')
    contract={}; manifest={}
    try: contract=json.loads((root/'CONTRACT.json').read_text())
    except Exception as e: errors.append(f'CONTRACT.json invalid: {e}')
    try: manifest=json.loads((root/'MANIFEST.json').read_text())
    except Exception as e: errors.append(f'MANIFEST.json invalid: {e}')
    for k in REQUIRED_CONTRACT_KEYS:
        if k not in contract: errors.append(f'contract missing key: {k}')
    if manifest.get('secret_policy') != 'references_only': errors.append('secret_policy must be references_only')
    if contract.get('os_id') and manifest.get('os_id') and contract['os_id'] != manifest['os_id']:
        errors.append('MANIFEST os_id != CONTRACT os_id')
    handoff=root/'14_LIBRARIAN/14_BUILDER_HANDOFF.md'
    if handoff.exists():
        text=handoff.read_text(encoding='utf-8')
        if 'STATUS: INCOMPLETE' in text: errors.append('Librarian handoff is incomplete')
        n=count_handoff_inputs(text)
        if n < 15: errors.append(f'Librarian handoff has {n}/15 explicit inputs')
    # crude but useful secret-pattern scanner
    patterns=[r'sk-[A-Za-z0-9_-]{16,}',r'ghp_[A-Za-z0-9]{20,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    for p in root.rglob('*'):
        if p.is_file() and p.stat().st_size < 2_000_000 and p.suffix.lower() not in {'.zip','.png','.jpg','.jpeg','.gif','.pdf'}:
            try: txt=p.read_text(errors='ignore')
            except: continue
            for pat in patterns:
                if re.search(pat,txt): errors.append(f'possible secret in {p.relative_to(root)}')
    print('AGK OS DOCTOR')
    for e in errors: print('FAIL:',e)
    for x in warnings: print('WARN:',x)
    if not errors: print('PASS')
    return 1 if errors else 0

def package(root,out,recovery=False):
    root=Path(root).resolve(); out=Path(out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if doctor_path(root): raise SystemExit('Doctor failed; refusing package')
    manifest=json.loads((root/'MANIFEST.json').read_text())
    suffix='recovery' if recovery else 'package'
    dest=out/f"{manifest['os_id']}-{manifest['version']}-{suffix}.zip"
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '.git' not in p.parts:
                z.write(p,p.relative_to(root.parent))
        if recovery:
            instructions="""RECOVERY ARTIFACT\n\n1. Verify checksum of this archive.\n2. Restore into a clean target scope.\n3. Rebind credential references from the secret manager.\n4. Restore durable data from the declared backup source.\n5. Run doctor.\n6. Run critical workflow from a fresh session.\n7. Verify Discord readback.\n8. Record evidence before traffic is restored.\n"""
            z.writestr(f"{root.name}/RECOVERY_README.txt",instructions)
    digest=hashlib.sha256(dest.read_bytes()).hexdigest()
    (dest.with_suffix(dest.suffix+'.sha256')).write_text(digest+'  '+dest.name+'\n')
    print(dest)

def doctor_pack():
    here=Path(__file__).resolve().parents[1]
    required=['00_CANONICAL/AGK_OS_CONTRACT.md','02_BUILDER_OS/README.md','03_LIBRARIAN_OS/README.md','programs/librarian.py','05_OS_TEMPLATE/MANIFEST.example.json']
    missing=[x for x in required if not (here/x).exists()]
    print('PACK DOCTOR')
    if missing:
        print('FAIL',missing); return 1
    print('PASS'); return 0

def main():
    ap=argparse.ArgumentParser(prog='agk_builder')
    sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('new'); p.add_argument('--name',required=True); p.add_argument('--slug'); p.add_argument('--theme',required=True); p.add_argument('--output',default='./generated')
    p=sp.add_parser('doctor'); p.add_argument('root')
    sp.add_parser('doctor-pack')
    p=sp.add_parser('package'); p.add_argument('root'); p.add_argument('--output',default='./dist')
    p=sp.add_parser('recovery'); p.add_argument('root'); p.add_argument('--output',default='./dist')
    a=ap.parse_args()
    if a.cmd=='new': scaffold(a)
    elif a.cmd=='doctor': raise SystemExit(doctor_path(a.root))
    elif a.cmd=='doctor-pack': raise SystemExit(doctor_pack())
    elif a.cmd=='package': package(a.root,a.output,False)
    elif a.cmd=='recovery': package(a.root,a.output,True)
if __name__=='__main__': main()
