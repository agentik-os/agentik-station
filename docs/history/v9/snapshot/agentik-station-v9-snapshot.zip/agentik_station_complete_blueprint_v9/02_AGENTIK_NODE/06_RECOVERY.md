# Disaster Recovery

## Required reconstructible assets

```text
1. Agentik Node version
2. deployment config repo
3. agentik.lock
4. OS/profile/skill repositories
5. encrypted state backup
6. secret recovery source
```

## Recovery sequence

```text
Fresh VPS
→ bootstrap host
→ install Agentik Node
→ apply exact lockfile
→ restore state
→ inject secrets
→ start Hermes
→ doctor
→ E2E
→ production
```

## Recovery acceptance test

At least periodically:

1. provision a new disposable VPS
2. restore from production artifacts
3. run `agentik doctor`
4. run sandbox E2E
5. compare expected state
6. destroy test VPS

A backup that has never been restored is not a proven backup.
