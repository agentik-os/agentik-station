# Installer Architecture

## Product UX target

```bash
git clone https://github.com/agentik-os/agentik-node
cd agentik-node
./agentik install
```

Future CLI contract:

```text
agentik init personal
agentik init organization
agentik apply
agentik os install <os>
agentik discord connect
agentik discord plan
agentik discord apply
agentik discord verify
agentik doctor
agentik update
agentik backup
agentik restore
```

## Node state machine

```text
NEW
↓
HOST_READY
↓
HERMES_READY
↓
ORG_READY
↓
READY_UNBOUND
↓ connect Discord
DISCORD_BOUND
↓ provision
DISCORD_PROVISIONED
↓ remove bootstrap admin + verify
RUNTIME_SECURED
↓ doctor + E2E
OPERATIONAL
```

## Installer order

```text
host validation
→ security baseline
→ Docker/runtime dependencies
→ Hermes
→ smoke test
→ Agentik Control plugin
→ install/pin Ponytail when DevOps/Builder OS selected
→ persistent gateway
→ memory provider
→ apply organization desired state
→ install OS packages
→ install persistent Directors/profiles
→ create Projects
→ create/bind Kanban Boards
→ connect capabilities
→ Node READY_UNBOUND
→ connect Discord
→ bootstrap handshake
→ Discord Bootstrap Director
→ inspect + plan + apply desired Discord state
→ persist bindings
→ routing verification
→ runtime privilege downgrade
→ doctor
→ E2E
→ OPERATIONAL
```

## Zero-manual-config objective

After `organization.yaml`, OS selections and external credentials are provided, a normal deployment must not require hand-creating Discord roles/categories/channels.

## Important

Prove the lifecycle manually once, then automate it. The installer automates known-good behavior; it does not hide unknown architecture.

## v4 Engineering Harness bootstrap

When a code-modifying OS is installed, the installer MUST also:

```text
apply engineering.policy.yaml
→ enable Hermes verification baseline
→ configure tool-loop guardrails for unattended execution
→ configure bounded delegation + worktree isolation
→ install/enable Ponytail
→ register model route aliases
→ register Gauntlet critic profiles/routes
→ register Engineering Episode hooks/indexes
→ run engineering doctor checks
```

The installer should configure Hermes-native primitives rather than ship duplicate runtimes.


## System OS bootstrap addition

Development/candidate Nodes install Builder OS as a first-class system OS after Hermes core and before ordinary domain OS authoring. Builder depends on Librarian and the DevOps Engineering Harness. A client/stable Node may omit authoring capabilities when policy requires, but every installed OS must have been produced by the Builder contract pipeline.
