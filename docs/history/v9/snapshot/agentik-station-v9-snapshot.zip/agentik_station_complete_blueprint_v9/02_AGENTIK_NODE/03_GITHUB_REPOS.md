# GitHub Repository Architecture

Initial repositories:

```text
agentik-os/
├── agentik-node
├── agentik-control
├── agentik-memory
├── agentik-skills
├── agentik-os-registry
└── director-devops
```

Later:

```text
director-journal
director-decision
director-content
...

os-devops
os-journal
os-decision
...
```

## agentik-node

Contains:
- bootstrap
- installer
- compose
- schemas
- doctor
- update logic
- recovery
- CI

## agentik-control

Hermes plugin.

## agentik-memory

Hermes Memory Provider.

## agentik-skills

Skill Tap / registry.

## agentik-os-registry

Catalog + OS manifests.

## director-*

Hermes Profile Distributions.

## Client config repo

Example:

```text
MoonBaseCapital/agentik-config/
├── node.yaml
├── organization.yaml
├── projects.yaml
├── os.yaml
├── integrations.yaml
├── discord.yaml
├── policies.yaml
└── agentik.lock
```

No secrets.
