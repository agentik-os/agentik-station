# Doctor and End-to-End Test

## Doctor sections

### Host
- OS/version
- disk
- firewall
- Tailscale
- Docker

### Hermes
- config
- provider
- gateway
- profiles
- projects
- boards
- plugins
- Ponytail when engineering OS installed
- memory provider
- security audit

### Organization
- registry
- hierarchy
- installed OSs
- project mappings
- context routing

### Discord
- application/bot reachable
- target guild bound
- desired-state hash known
- current-state inventory fresh
- no unresolved provisioning diff (or explicitly accepted drift)
- role hierarchy valid
- required roles/categories/channels exist
- immutable bindings present
- each exposed OS maps to a director/profile + project + board
- mission thread/session behavior works
- Bootstrap Director capability disabled outside bootstrap window
- bot does **not** retain Administrator after bootstrap
- runtime permissions satisfy required operations

### Capabilities
- GitHub
- Linear
- Notion
- DB
- optional voice

### Execution
- delegation
- worktree
- Kanban
- Goal loop
- review
- evidence

### Operations
- logs
- backup
- restore metadata
- version lock
- Discord drift monitor

## Canonical E2E

```text
Discord bound OS channel
→ Hermes thread session
→ context resolution using immutable channel binding
→ correct organization
→ correct OS
→ correct Nano Director
→ AGK Mission
→ Hermes root Kanban task
→ task graph
→ subagents/profiles
→ worktree
→ implementation
→ deterministic gates
→ Ponytail review for engineering work
→ QA
→ independent review
→ PR
→ CI
→ staging
→ live verification
→ evidence
→ Notion / Linear sync where configured
→ memory candidate
→ Discord final report
```

If the Node cannot pass this after a fresh rebuild, it is not production-ready.

## Engineering Harness Doctor

Doctor must additionally prove:

```text
✓ Hermes verify_on_stop policy resolved
✓ tool-loop guardrails resolved for unattended profiles
✓ Ponytail installed/enabled where required
✓ delegation concurrency/depth bounded
✓ worktree isolation available
✓ model route aliases resolve
✓ fallback route configured for critical profiles
✓ Gauntlet critic profile can run independently
✓ engineering Loop-Graph can compile to Kanban
✓ native Hermes logs readable
✓ Engineering Episode index writable
✓ self-improvement policy does not permit security/policy weakening
```

E2E engineering test:

```text
create disposable mission
→ generate graph
→ spawn isolated implementation worktree
→ make tiny code change
→ produce verification evidence
→ run independent critic
→ integrate
→ attach episode evidence
→ ensure clean/recoverable state
```
