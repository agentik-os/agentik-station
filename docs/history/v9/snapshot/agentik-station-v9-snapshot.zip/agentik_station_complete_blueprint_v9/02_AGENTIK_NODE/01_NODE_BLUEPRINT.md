# Agentik Node / Station Blueprint

A **Node** is one deployed organization/trust boundary. **Station** is the complete distribution and lifecycle that installs/operates Nodes.

## Gareth Station deployment modes

```text
station-system
private-self
personal-projects
agentik-dev
os-factory
lab
```

## Client deployment mode

```text
client-station = separate VPS/Node
```

## Node contains

Hermes runtime, AGK desired state, organization/OS registry, profiles, skills/plugins, projects/boards, dedicated OS Discord surfaces, evidence, observability, backup/recovery and Station update agent.

## Desired vs mutable vs secret

Desired state belongs in Git/immutable releases. Mutable state (sessions, memory, DBs, evidence, artifacts) is namespaced and backed up. Secrets live in external/profile/zone secret stores and are referenced, never packaged.
