# Recommended Station Filesystem

See `01_STATION_ARCHITECTURE/02_FILESYSTEM_AND_USERS.md` for the full trust-zone layout.

Canonical top-level split:

```text
/etc/station      desired configuration/policies
/opt/station      immutable Station programs/releases/hooks
/srv/station      zone/project/OS operational assets
/var/lib/station  registries/evidence/events/state indexes
/var/log/station  Station logs
/var/backups      local staging only; offsite encrypted target required
```

Hermes homes belong to their zone Unix users. Client production state does not live on the Gareth Station.
