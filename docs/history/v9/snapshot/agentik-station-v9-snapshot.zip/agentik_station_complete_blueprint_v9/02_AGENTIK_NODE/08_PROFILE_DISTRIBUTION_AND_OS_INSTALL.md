# Profile Distribution and OS Installation

## Profile Distribution

A Nano Director can be distributed through Git.

Concept:

```text
director-devops repo
→ Hermes profile install
→ local profile instance
```

Reusable:
- SOUL
- config defaults
- skills
- cron
- MCP configuration

Local:
- credentials
- sessions
- memory
- deployment-specific config

## OS installation

Installing an OS is broader than installing a profile.

Example:

```text
Install DevOps OS
↓
verify OS manifest
↓
install Nano Director distribution
↓
install required skills/bundles
↓
install/enable required plugins
↓
check required capabilities
↓
create memory namespaces
↓
create/attach Project
↓
create/bind Board
↓
configure Discord route
↓
run OS Doctor
↓
run sandbox acceptance test
```

## Update

OS update should:
- preserve local secrets
- preserve memory
- preserve organization-specific mappings
- migrate OS schema when required
- rerun doctor
- allow rollback
