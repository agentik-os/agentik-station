# Zero-to-Operational Bootstrap

## Goal

The installation experience should be:

```text
1. install Agentik Node
2. provide organization config + selected OSs
3. connect Discord
4. authorize bootstrap
5. let the Bootstrap Director provision/reconcile everything
6. start operating
```

## Bootstrap actor

Persistent system profile:

```text
discord-bootstrap-director
```

It is **not** a general super-agent.

Allowed system capabilities:

```text
discord.state.read
discord.bootstrap.plan
discord.bootstrap.apply
discord.roles.manage.bootstrap
discord.channels.manage.bootstrap
discord.permissions.manage.bootstrap
discord.bindings.write
discord.bootstrap.verify
discord.bootstrap.demote
```

Explicitly denied by default:

```text
shell.root
secrets.export
other_organization.access
production.deploy
arbitrary_github.write
```

## Desired state inputs

```text
organization.yaml
installed-os registry
OS discord/surface manifests
discord.bootstrap.yaml
team-bindings.yaml
policies.yaml
```

## Reconcile algorithm

```text
FETCH current guild state
↓
NORMALIZE resources by IDs + managed tags
↓
COMPILE desired state
↓
MATCH existing resources
↓
PLAN
  create
  adopt
  update
  move
  permission-diff
  bind
  warn
  destructive-change (blocked by default)
↓
APPLY safe operations
↓
VERIFY
↓
PERSIST binding registry
↓
REMOVE Administrator
↓
VERIFY runtime role
↓
EVIDENCE
```

## Existing server behavior

Default mode is **adopt-and-extend**, not reset.

- never delete unknown channels by default
- do not rename user-managed channels unless explicitly declared managed
- if a suitable role/category/channel already exists, adopt it after validation
- record the Discord ID so future applies are stable
- produce warnings for naming collisions
- destructive migrations require explicit policy + approval

## Empty server behavior

For a new/empty server, the Bootstrap Director can apply the complete desired structure automatically.

## Completion

A successful bootstrap writes:

```text
/etc/agentik/discord.desired.yaml
/var/lib/agentik/discord/state.yaml
/var/lib/agentik/discord/bindings.yaml
/var/lib/agentik/evidence/discord-bootstrap/<run-id>/...
```

and transitions the Node to `RUNTIME_SECURED`, then `OPERATIONAL` after doctor/E2E.
