# Update Pipeline

## Inputs

- Agentik release
- Hermes release
- OS releases
- profile distributions
- skills
- plugin versions
- sidecar image versions

## Lockfile

`agentik.lock` should record immutable compatible references.

## Process

```text
update detected
↓
build ephemeral test Node
↓
apply current config
↓
upgrade candidate
↓
doctor
↓
security checks
↓
test profiles
↓
test projects / boards
↓
test MCP
↓
run full E2E
↓
if pass → release candidate
↓
promote stable
```

## Rollback

Keep:
- prior lockfile
- prior runtime image/digest
- state backup
- migration metadata

## Production rule

No unreviewed `latest`.
