from __future__ import annotations
import json
from . import schemas, tools, state

SAFE_BEFORE_PLAN={'station_mission_plan','skill_view','memory','read_file'}
MUTATING_HINTS=('write','edit','delete','send','deploy','create','update','execute','terminal','shell','discord_admin')

def _pre_tool(tool_name, params, task_id=None, session_id=None, **kwargs):
    if tool_name in SAFE_BEFORE_PLAN: return None
    # Exact mission binding is resolved by the Station host integration. This hook is the fail-closed scaffold:
    # when STATION_CURRENT_MISSION_ID is injected into the worker environment, operative/mutating tools require a plan.
    import os
    mid=os.environ.get('STATION_CURRENT_MISSION_ID')
    if not mid: return None
    if any(x in tool_name.lower() for x in MUTATING_HINTS) and not state.load(mid):
        return {"block": True, "reason": "Plan-first gate: call station_mission_plan before operative/mutating work."}
    return None

def register(ctx):
    ctx.register_tool(name='station_mission_plan',toolset='station-experience',schema=schemas.MISSION_PLAN,handler=tools.mission_plan)
    ctx.register_tool(name='station_plan_update',toolset='station-experience',schema=schemas.PLAN_UPDATE,handler=tools.plan_update)
    ctx.register_tool(name='station_progress',toolset='station-experience',schema=schemas.PROGRESS,handler=tools.progress)
    ctx.register_tool(name='station_mission_close',toolset='station-experience',schema=schemas.CLOSE,handler=tools.close)
    ctx.register_hook('pre_tool_call', _pre_tool)
