# station-discord-experience

Hermes plugin scaffold for Station's plan-first semantic mission UX.

The plugin owns structured mission plan/progress state and plan-first tool gating. A host-owned Discord Experience Worker binds mission IDs to Discord message IDs and renders/edit Components V2 messages. The model never supplies bot tokens or arbitrary message destinations.

Production hardening still required during implementation:
- wire Station session/mission binding into plugin context instead of relying only on environment fallback;
- integrate exact Hermes hook directive return contract for the pinned Hermes version;
- implement Discord transport with rate-limit/retry handling;
- implement authorized component interaction callbacks;
- validate all component limits against the pinned Discord API version.
