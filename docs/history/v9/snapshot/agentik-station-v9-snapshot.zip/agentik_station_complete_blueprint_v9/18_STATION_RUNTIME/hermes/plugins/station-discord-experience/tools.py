from __future__ import annotations
import json, time
from . import state

def _ok(payload): return json.dumps({"success":True, **payload}, ensure_ascii=False)

def mission_plan(args, **kwargs):
    mid=args['mission_id']
    payload={"mission_id":mid,"objective":args['objective'],"acceptance":args.get('acceptance',[]),"nodes":args.get('nodes',[]),"status":"planning","plan_revision":1,"current_node_id":None,"problems":[],"artifacts":[]}
    state.save(mid,payload,'plan_created')
    return _ok({"mission_id":mid,"plan_revision":1})

def plan_update(args, **kwargs):
    cur=state.load(args['mission_id'])
    if not cur: return json.dumps({"error":"mission plan not found"})
    cur['nodes']=args.get('nodes',cur.get('nodes',[])); cur['plan_revision']=int(cur.get('plan_revision',1))+1; cur['last_revision_reason']=args['reason']
    state.save(args['mission_id'],cur,'plan_revised')
    return _ok({"mission_id":args['mission_id'],"plan_revision":cur['plan_revision']})

def progress(args, **kwargs):
    cur=state.load(args['mission_id'])
    if not cur: return json.dumps({"error":"mission plan required before progress"})
    cur['status']='running'; cur['current_node_id']=args.get('node_id'); cur['last_summary']=args['summary']; cur['last_event_type']=args['event_type']
    for n in cur.get('nodes',[]):
        if args.get('node_id') and n.get('id')==args['node_id']:
            if args['event_type'] in ('node_completed','verification_passed'): n['status']='done'
            elif args['event_type'] in ('node_blocked','verification_failed'): n['status']='blocked'
            elif args['event_type'] in ('node_started','verification_started'): n['status']='running'
    state.save(args['mission_id'],cur,args['event_type'])
    return _ok({"mission_id":args['mission_id'],"status":cur['status']})

def close(args, **kwargs):
    cur=state.load(args['mission_id'])
    if not cur: return json.dumps({"error":"mission plan required before close"})
    cur['status']=args['status']; cur['outcome']=args['outcome']; cur['problems']=args.get('problems',[]); cur['artifacts']=args.get('artifacts',[]); cur['closed_at']=time.time()
    state.save(args['mission_id'],cur,'mission_'+args['status'])
    return _ok({"mission_id":args['mission_id'],"status":args['status']})
