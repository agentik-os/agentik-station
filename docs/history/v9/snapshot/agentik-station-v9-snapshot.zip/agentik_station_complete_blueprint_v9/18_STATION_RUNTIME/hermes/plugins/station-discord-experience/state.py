from __future__ import annotations
import json, os, sqlite3, time
from pathlib import Path

DB = Path(os.environ.get('STATION_DISCORD_EXPERIENCE_DB','/var/lib/station/discord-experience/state.db'))

def _db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con=sqlite3.connect(DB)
    con.execute('create table if not exists mission_state (mission_id text primary key, payload text not null, updated real not null)')
    con.execute('create table if not exists events (id integer primary key autoincrement, mission_id text, kind text, payload text, created real not null)')
    return con

def load(mission_id):
    con=_db(); row=con.execute('select payload from mission_state where mission_id=?',(mission_id,)).fetchone(); con.close()
    return json.loads(row[0]) if row else None

def save(mission_id, payload, kind='state'):
    now=time.time(); con=_db(); raw=json.dumps(payload,ensure_ascii=False)
    con.execute('insert into mission_state(mission_id,payload,updated) values(?,?,?) on conflict(mission_id) do update set payload=excluded.payload,updated=excluded.updated',(mission_id,raw,now))
    con.execute('insert into events(mission_id,kind,payload,created) values(?,?,?,?)',(mission_id,kind,raw,now)); con.commit(); con.close()
    return payload
