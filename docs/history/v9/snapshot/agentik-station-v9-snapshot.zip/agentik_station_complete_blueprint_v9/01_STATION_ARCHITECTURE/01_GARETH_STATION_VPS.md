# Gareth Station VPS Architecture

```text
GARETH STATION VPS
│
├── HOST PLANE (root / station-admin)
│   ├── Ubuntu/Linux baseline
│   ├── Tailscale
│   ├── firewall / SSH / fail2ban
│   ├── Docker/rootless project sandboxes
│   ├── systemd
│   ├── encrypted backup client
│   └── disk/log/health monitoring
│
├── STATION SYSTEM (station-system)
│   ├── desired state + lockfiles
│   ├── module/OS registry
│   ├── context/binding registry
│   ├── fleet metadata
│   ├── evidence + update receipts
│   ├── Station Maintainer OS control surface
│   └── Discord Bootstrap control surface
│
├── PRIVATE SELF (gareth-private)
│   ├── independent HERMES_HOME
│   ├── private personal OS profiles/bots
│   ├── private memory/data
│   └── sanitized outbound capabilities only
│
├── PERSONAL PROJECTS (gareth-projects)
│   ├── controller HERMES_HOME
│   └── projects/
│       ├── project-a container/volume/secrets/board
│       ├── project-b container/volume/secrets/board
│       └── project-n ...
│
├── AGENTIK DEV (agentik-dev)
│   ├── independent HERMES_HOME
│   ├── Agentik / AGK / Station repos
│   ├── staging credentials only by default
│   ├── DevOps/QA/Engineering profiles
│   └── worktrees
│
├── OS FACTORY (os-factory)
│   ├── independent HERMES_HOME
│   ├── Builder OS
│   ├── Librarian OS
│   ├── DevOps OS + Ponytail
│   ├── OS templates/schemas
│   ├── package registry staging
│   └── synthetic fixtures, not client raw data
│
└── LAB / HERMES EDGE (station-lab)
    ├── independent Hermes checkout/HERMES_HOME
    ├── tracks upstream main
    ├── no prod tokens
    ├── synthetic Discord/test guild where possible
    └── compatibility/regression suite
```

## Important

Client production Stations are not subdirectories here. They are separate Nodes/VPSs managed through fleet metadata and explicit control operations.
