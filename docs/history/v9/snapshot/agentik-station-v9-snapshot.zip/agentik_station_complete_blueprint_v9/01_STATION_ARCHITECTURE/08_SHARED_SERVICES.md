# Shared Services

Safe-to-share **code/services** include:
- Station installer/controller code;
- AGK schemas;
- public/reviewed OS packages;
- reviewed skills/plugins pinned by SHA;
- observability schema;
- fleet health protocol.

Unsafe-to-share **state** by default:
- credentials;
- raw memories;
- sessions;
- client databases;
- project working trees;
- deployment tokens.

Shared service does not mean shared trust domain.
