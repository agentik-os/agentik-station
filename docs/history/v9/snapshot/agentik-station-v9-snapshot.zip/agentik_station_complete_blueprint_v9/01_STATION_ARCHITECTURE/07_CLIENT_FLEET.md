# Future Client Architecture

## Default

```text
1 serious client = 1 Station / Node / VPS
```

A client Station contains only that organization plus required system OSs and installed client OSs.

```text
CLIENT STATION
├── host/security
├── station-system
├── Hermes stable runtime
├── client organization profiles
├── Builder/DevOps only if contract requires local build capability
├── dedicated OS bots/channels
├── scoped integrations/secrets
├── evidence
└── backup/recovery
```

## Central fleet operations

Gareth Station may request:
- version/health/doctor status;
- update plan;
- deployment/recovery operation under authorization;
- sanitized evidence receipt.

It does not receive raw client memory or credentials merely to administer versions.
