# Filesystem and Unix User Layout

```text
/etc/station/
├── station.yaml
├── trust-zones.yaml
├── fleet.yaml
├── update-policy.yaml
├── policies/
└── hermes-managed/

/opt/station/
├── bin/
├── programs/
├── hooks/
├── releases/
│   ├── station/
│   └── hermes/
└── current -> releases/station/<version>

/srv/station/
├── zones/
│   ├── private-self/
│   ├── personal-projects/
│   ├── agentik-dev/
│   ├── os-factory/
│   └── lab/
├── os-registry/
├── projects/
└── fleet/                 # metadata/config only

/var/lib/station/
├── registry/
├── bindings/
├── evidence/
├── events/
├── updater/
└── backups-index/

/var/log/station/
└── ...
```

Hermes homes remain owned by their zone users, e.g. `/home/gareth-private/.hermes` and `/home/os-factory/.hermes`.

## No shared writable repo checkout

One zone must not mutate another zone's checkout. Shared source is distributed as immutable release/package content; writable workspaces are zone/project specific.
