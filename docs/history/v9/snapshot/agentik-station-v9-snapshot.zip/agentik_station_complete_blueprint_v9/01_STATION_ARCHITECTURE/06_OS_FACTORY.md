# OS Factory Zone

OS Factory is where reusable operational intelligence is manufactured.

```text
Librarian OS
    ↓ sourced domain packet
Builder OS
    ↓ AGK contract/package
DevOps OS
    ↓ implementation + engineering harness
QA/Evals
    ↓ evidence
Registry Candidate
```

The factory uses synthetic/redacted fixtures for reusable OS development. Client-specific implementation may happen on the client's Node or an explicitly approved isolated delivery environment.

The user-supplied Builder/Librarian pack is integrated in `17_RUNTIME_OS_PACKAGES/` and preserved in `98_SOURCE_PACKS/`.
