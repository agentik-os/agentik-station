# Data, Memory and Secrets

## Three separate concepts

```text
Knowledge = canonical/retrievable facts/docs with provenance
Memory    = profile/OS continuity and learned context
Secrets   = credentials/keys/tokens; never knowledge or memory
```

## Namespace key

```text
organization / trust-zone / project / os / profile / environment
```

## Secret resolution

An OS package declares only capability and secret references. Runtime resolves a short-lived or scoped credential after authorization. Secret values never appear in OS ZIPs, evidence bundles or Discord command help.

## Memory promotion

Hermes self-improvement may propose memories/skills. Security policy, client boundaries, release gates and Station Constitution cannot be weakened through automatic learning; changes require governed promotion.


## Connected accounts
Composio API keys, OAuth material, connected-account IDs and session MCP URLs are live runtime secrets/references. They do not belong in OS packages. Personal/company/client binding scopes never merge by inference.
