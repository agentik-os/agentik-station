# Discord Topology

## Server bootstrap

A bootstrap integration with temporary Administrator permission can:
- inspect existing server state;
- plan/diff desired structure;
- create/adopt roles/categories/channels;
- configure permission overwrites;
- bind stable Discord IDs to OS/profile/project/board metadata;
- create how-to pins and command surfaces;
- verify routes;
- remove bootstrap Administrator permission.

## Dedicated OS bots

Each canonical OS has a dedicated Nano Director bot + primary channel. Station records:

```text
guild_id
os_id
nano_director_profile_id
application_id
bot_user_id
channel_id
role_id
command_set_version
binding_hash
```

Bot tokens remain external secrets. If a bot credential/application has not been enrolled, the OS can be installed but cannot pass `DISCORD_BOUND` / fresh-session / release acceptance.

## Internal specialists

Specialists are Hermes profiles/Bot Group members/Kanban workers. They do not require individual Discord applications unless an OS contract explicitly promotes them to a separate public identity.
