# Private Self-Development Zone

Purpose: private personal operating systems and sensitive self-development context.

## Rules

- own Unix user and HERMES_HOME;
- dedicated personal OS bots/profiles;
- raw journal/private memory stays here;
- no automatic access from Agentik dev, OS Factory or client Nodes;
- cross-zone exports are explicit summaries/signals, never implicit raw-memory reads;
- production/code deployment capabilities normally absent;
- backups use the highest privacy tier.

Example sanctioned export:

```json
{"signal":"availability","value":"reduced","expires_at":"..."}
```

Not sanctioned by default: raw private entries, relationship notes or whole memory stores.
