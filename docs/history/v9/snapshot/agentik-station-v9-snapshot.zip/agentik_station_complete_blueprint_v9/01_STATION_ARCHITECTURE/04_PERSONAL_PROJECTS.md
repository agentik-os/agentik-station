# Personal Projects Zone

A personal project is not allowed to become an unbounded folder inside the Station.

Each project descriptor declares:

```yaml
project:
  id: example
  trust_zone: personal-projects
  sensitivity: private
  repo_ref: github:owner/repo
  runtime: container
  hermes_profile: project-example-director
  os_bindings: [devops-os]
  secret_namespace: gareth/projects/example
  memory_namespace: gareth/projects/example
  allowed_roots:
    - /srv/station/zones/personal-projects/projects/example
```

Projects receive independent workspaces/volumes and credential namespaces. A project can be promoted to a dedicated Unix user or separate Node when sensitivity/resource needs justify it.
