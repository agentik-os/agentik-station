# Composio in Station

Composio is installed as a **capability adapter**, not as a shared global identity bucket.

Recommended topology:

```text
Gareth Station
├── private-self        -> private Composio credential/subject namespace
├── personal-projects   -> project-scoped bindings
├── agentik-dev         -> Agentik development bindings
├── os-factory          -> Builder/Librarian integrations when explicitly needed
└── lab                 -> test credentials only

Client Station A        -> independent Composio credentials/bindings
Client Station B        -> independent Composio credentials/bindings
```

Do not copy connected-account references between trust zones. A package may request a capability; the live Node resolves the correct account binding at install/onboarding time.
