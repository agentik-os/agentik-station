# Agentik Product Development Zone

Contains product engineering for Agentik, AGK, Station and reviewed Hermes integration work.

## Allowed

- Agentik/AGK/Station repositories;
- development/staging systems;
- Builder/DevOps calls through typed capabilities;
- isolated worktrees;
- engineering harness;
- candidate release creation.

## Not allowed by default

- private-self raw memory;
- client production credentials/data;
- direct modification of the LAB upstream Hermes checkout;
- direct stable release bypass.

Hermes itself is treated as upstream. Station extensions use plugins/hooks/distributions unless an intentional Hermes fork has its own explicit lifecycle.
