# Gareth Station Organization Example

```text
Gareth
├── Station / Operator
│   ├── Station Maintainer OS
│   ├── Discord Bootstrap OS
│   └── Fleet metadata
│
├── Private Self  [private-self trust zone]
│   ├── Identity OS
│   ├── Mindset OS
│   ├── Journal OS
│   ├── Decision OS
│   ├── Goals / Routine OS
│   ├── Relationship / Connector OS
│   ├── Learning OS
│   └── Travel / Wealth / Performance OS
│
├── Personal Projects [personal-projects trust zone]
│   └── project descriptors + project-specific OS stacks
│
├── Business [Gareth-owned business metadata/workflows]
│   ├── Strategy
│   ├── Sales
│   ├── Content
│   ├── Network
│   └── Capital
│
├── Agentik Product [agentik-dev trust zone]
│   ├── Agentik
│   ├── AGK
│   ├── Station
│   └── Hermes integration
│
└── OS Factory [os-factory trust zone]
    ├── Librarian OS
    ├── Builder OS
    ├── DevOps OS
    ├── QA/Evals
    └── Registry candidate pipeline
```

Client production organizations are separate Stations/Nodes, not children with shared raw state.
