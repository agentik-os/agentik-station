# Provider Routing

Provider routing is policy-based, not hard-coded personality.

Example task classes:
- orchestration/planning;
- coding/programming;
- deep research synthesis;
- fast classification/routing;
- long-context review;
- local/private processing;
- multimodal.

Each route declares preferred provider/model family, fallbacks, minimum capability, cost/latency tier, privacy requirements and eval thresholds. Provider credentials remain external references.
