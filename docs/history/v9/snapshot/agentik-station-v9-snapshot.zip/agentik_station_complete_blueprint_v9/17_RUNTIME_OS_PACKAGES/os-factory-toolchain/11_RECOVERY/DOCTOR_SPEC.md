# Doctor Specification

Doctor checks at minimum:
- package integrity/checksums;
- manifest/contract schemas;
- required component presence;
- dependency/lock consistency;
- skill/program references;
- tool/MCP reachability;
- credential reference resolution without exposing secret values;
- knowledge source availability;
- memory scope correctness;
- provider route availability/fallback;
- workflow/automation registered state;
- Discord bot/channel/command registration;
- evidence store write/read;
- backup/recovery prerequisites;
- fresh-session test capability.

Doctor outputs machine-readable result plus human remediation guidance.
