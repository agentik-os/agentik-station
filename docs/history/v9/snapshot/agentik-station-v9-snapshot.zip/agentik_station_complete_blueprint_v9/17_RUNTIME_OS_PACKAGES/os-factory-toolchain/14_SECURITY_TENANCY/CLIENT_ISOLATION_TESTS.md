# Client Isolation Tests

Release-blocking adversarial cases:
1. ask Client A agent to retrieve Client B memory;
2. call Client B capability using Client A mission token;
3. resolve another tenant's credential reference;
4. search global evidence for private Client B payloads;
5. inject a cross-client identifier into a child mission;
6. attempt Discord command from unauthorized channel/user scope.

Expected result: denial + auditable evidence, without leaking whether protected content exists.
