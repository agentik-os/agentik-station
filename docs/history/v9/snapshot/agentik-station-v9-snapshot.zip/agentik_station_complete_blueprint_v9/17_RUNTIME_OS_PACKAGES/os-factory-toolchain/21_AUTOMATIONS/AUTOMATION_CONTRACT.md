# Automation Contract

Automation is a durable trigger that launches a declared workflow/mission. It must declare:
- automation_id;
- owner OS;
- trigger type and schedule/event condition;
- workflow/capability;
- inputs and durable state dependencies;
- permissions and side-effect class;
- deduplication/idempotency;
- retry/backoff;
- notification/escalation;
- disable/kill switch;
- evidence;
- fresh-session acceptance result.

An automation that only works after a warm interactive session is not enabled.
