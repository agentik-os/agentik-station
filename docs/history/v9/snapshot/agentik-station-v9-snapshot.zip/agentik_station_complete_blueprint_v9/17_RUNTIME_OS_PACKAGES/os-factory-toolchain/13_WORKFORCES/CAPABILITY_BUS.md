# Capability Bus

Capability URI suggestion:
`agk://<organization>/<os>/<capability>@<version>`

Calls declare:
- caller OS/mission;
- requested capability;
- typed input;
- granted scopes;
- deadline/idempotency key;
- expected evidence class.

Receiver returns typed output plus evidence IDs. The caller never gains implicit access to the receiver's memory or credentials.
