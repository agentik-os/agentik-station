# MCP / Tool Contract

Every tool capability declares:
- capability_id and owner;
- transport (MCP/API/Composio/native);
- auth reference name and required scopes;
- input/output schemas;
- read/write/side-effect class;
- timeout/retry/backoff;
- idempotency semantics;
- rate-limit behavior;
- error taxonomy;
- observability/evidence;
- sandbox/staging availability;
- live-test procedure;
- data residency / tenancy implications.

A tool is not “installed” for release purposes until its required capability passes a live probe in target scope.
