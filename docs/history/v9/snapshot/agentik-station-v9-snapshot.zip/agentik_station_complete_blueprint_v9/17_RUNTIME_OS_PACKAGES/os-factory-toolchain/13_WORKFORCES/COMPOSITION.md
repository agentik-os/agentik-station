# Multi-OS Workforce Composition

OSs collaborate through typed capabilities, never by assuming shared internal state.

Example:

```mermaid
flowchart LR
  CEO[CEO Operator OS]
  STRAT[Strategy OS]
  LEAD[Lead OS]
  CONTENT[Content OS]
  DEV[DevOps OS]
  DEC[Decision OS]

  CEO -->|strategy.request| STRAT
  CEO -->|pipeline.health| LEAD
  STRAT -->|campaign.brief| CONTENT
  DEV -->|release.status| CEO
  DEC -->|decision.review| CEO
```

A Workforce may contain dozens of agents because governance is at OS/capability/mission boundaries rather than one giant multi-agent chat.
