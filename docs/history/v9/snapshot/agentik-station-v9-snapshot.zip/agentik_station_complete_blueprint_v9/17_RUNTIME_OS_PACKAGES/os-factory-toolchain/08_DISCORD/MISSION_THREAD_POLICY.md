# Mission Thread Policy

1. Never run unrelated missions in one thread.
2. Thread name should be human-readable plus short mission ID.
3. Bot posts plan and acceptance criteria near thread start.
4. Tool progress is summarized, not spammed.
5. Decisions, approvals and blockers are durable events.
6. On completion, bot posts result + evidence + remaining risks.
7. Thread archives only after mission durable state is `completed` or explicitly cancelled.
8. Agent-to-agent work carries typed context, never the whole unrelated chat history.
