# Evaluation Framework

Required layers:
1. contract completeness;
2. deterministic unit tests;
3. schema/state-machine tests;
4. integration contract tests;
5. live tool probes;
6. domain-quality evals;
7. permission/tenancy adversarial evals;
8. recovery/rollback evals;
9. Discord surface/readback eval;
10. fresh-session critical-path acceptance.

Every release-blocking eval has an owner, threshold, fixture/data scope and evidence output.
