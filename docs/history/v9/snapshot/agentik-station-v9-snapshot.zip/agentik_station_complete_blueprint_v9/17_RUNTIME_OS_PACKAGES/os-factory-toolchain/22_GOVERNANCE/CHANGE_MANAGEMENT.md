# Change Management

Every change is classified:
- patch: compatible fixes/docs/evals;
- minor: backward-compatible capabilities/workflows;
- major: breaking contract/schema/capability behavior.

A domain research refresh may trigger any class depending on implementation impact. Research source changes are not silently merged into released behavior.
