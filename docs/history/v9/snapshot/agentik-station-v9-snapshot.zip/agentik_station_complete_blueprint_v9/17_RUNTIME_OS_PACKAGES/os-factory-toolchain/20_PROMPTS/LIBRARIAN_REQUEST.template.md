# Librarian Deep Research Request

Run `/book --deep` for the following OS domain.

- Theme:
- Builder mission:
- Target users:
- Outcomes:
- Constraints:
- Recency-sensitive topics:
- Known competing approaches:

Find real canonical works and primary/official sources. Verify provenance. Extract concepts rather than copyrighted prose. Select the 15 strongest non-redundant inputs and map each into concrete Builder changes: skills, deterministic programs, tool contracts, knowledge/memory, provider routes, workflows, automations, evals, Discord, doctor and recovery.

Deliver `14_BUILDER_HANDOFF.md` plus machine-readable source packet and traceability matrix.
