# AGK Builder OS + Librarian OS — Complete Canonical Pack

**Date:** 2026-09-03  
**Purpose:** Build, verify, package, install, evolve and recover complete AGK Operative Systems.

This pack is reconstructed from the AGK / Agentik / Hermes architecture defined in the working conversations and setup decisions. It is intentionally **not a copy of the existing GitHub repository**.

## The idea in one sentence

> Librarian finds the best domain knowledge; Builder turns that knowledge into a governed, executable, testable, recoverable Operative System.

## Canonical hierarchy

```mermaid
flowchart TD
    A[Agentik Product / Workspace / Marketplace]
    B[AGK Control Plane / OS Standard / Governance]
    N[Agentik Node]
    H[Hermes Execution Kernel]
    O[Organization]
    MD[Macro Domain]
    D[Domain]
    OS[Recursive Operative System]
    ND[Nano Director]
    NT[NanoTeam / Team Director]
    SA[Specialist Subagents]
    C[Skills · Programs · Capabilities · Tools]

    A --> B --> N --> H --> O --> MD --> D --> OS --> ND --> NT --> SA --> C
```

## Canonical OS equation

```text
OS =
  package
+ Nano Director
+ NanoTeam
+ profiles
+ ordered skills
+ deterministic programs
+ MCP/tool contracts
+ knowledge and memory scopes
+ provider routes
+ workflows
+ automations
+ evaluations
+ Discord control surface
+ doctor
+ rollback
+ recovery artifact
+ Librarian best advice from sourced domain works
+ Discord commands on the dedicated OS bot
```

## Non-negotiable build doctrine

1. **Plan first.** Never jump from an idea directly to implementation.
2. **Research first.** Every domain OS receives a Librarian deep-research handoff before build completion.
3. **Graph loop.** Model actors, states, dependencies, inputs, outputs and failure paths before coding.
4. **Verification engineering.** Every important requirement has an evidence-producing verification method.
5. **Test-first where deterministic.** Programs, schemas, state transitions and contracts are tested before release.
6. **Live test.** A declared integration is not accepted because config exists; it must work in the deployed environment.
7. **Fresh-session acceptance.** Persistent automation is not considered enabled until it succeeds from a fresh session using only deployed context, skills, tools, durable state and declared inputs.
8. **No secrets in OS packages.** Packages contain secret references/contracts, never credentials.
9. **Dedicated Discord surface.** Each OS has a dedicated bot and dedicated channel; the bot is the Nano Director surface.
10. **Recoverability is part of the product.** Doctor, rollback and recovery artifacts are required, not optional operations work.

## What is included

- Builder OS specification, NanoTeam, skills, programs, workflows and gates.
- Librarian OS specification, research protocol, source scoring, synthesis and Builder handoff.
- Reusable OS package template.
- Python CLI to scaffold, validate, package and create recovery artifacts.
- Source-packet compiler and Librarian handoff validator.
- JSON Schemas for manifests, contracts, missions, capabilities and evidence.
- Discord mission/thread rules and slash-command catalog.
- Provider routing and MCP/tool contract templates.
- Memory / knowledge boundaries.
- Registry/install/update/fork/rollback lifecycle.
- Multi-OS Workforce and typed-capability composition rules.
- Security and tenancy model.
- Evaluations and acceptance checklists.
- Example CEO Operator OS generated from the same contract.

## Start here

```bash
cd AGK_Builder_Librarian_OS_COMPLETE_2026-09-03
python3 programs/agk_builder.py doctor-pack
python3 programs/agk_builder.py new \
  --name "CEO Operator" \
  --slug ceo-operator \
  --theme "CEO operating system" \
  --output ./generated
```

Then complete the Librarian packet:

```bash
python3 programs/librarian.py init \
  --theme "CEO operating system" \
  --output ./generated/ceo-operator/14_BUILDER_HANDOFF.md
```

Once real source records have been gathered and summarized into a source packet:

```bash
python3 programs/librarian.py validate ./generated/ceo-operator/librarian/source_packet.json
python3 programs/agk_builder.py doctor ./generated/ceo-operator
python3 programs/agk_builder.py package ./generated/ceo-operator --output ./dist
python3 programs/agk_builder.py recovery ./generated/ceo-operator --output ./dist
```

## Build pipeline

```mermaid
flowchart LR
    I[Intent / Mission] --> P[Plan]
    P --> L[Librarian /book --deep]
    L --> M[15 Best Inputs Matrix]
    M --> S[OS Specification]
    S --> G1[Gate 1 Plan]
    G1 --> G2[Gate 2 Orchestration]
    G2 --> G3[Gate 3 Programming]
    G3 --> G4[Gate 4 Agentic]
    G4 --> T[TDD / Build]
    T --> R[Independent Review]
    R --> D[Doctor]
    D --> PKG[Immutable Package]
    PKG --> INST[Registry / Install]
    INST --> DR[Discord Readback]
    DR --> FS[Fresh-session Acceptance]
    FS --> REL[Release]
    REL --> OBS[Observe / Eval / Improve]
    OBS --> UP[Update or Rollback]
```

See `FILE_INDEX.md` for the full pack.
