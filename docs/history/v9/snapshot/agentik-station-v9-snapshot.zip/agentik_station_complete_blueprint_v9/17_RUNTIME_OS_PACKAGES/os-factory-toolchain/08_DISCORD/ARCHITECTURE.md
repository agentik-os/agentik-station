# Discord as OS Control Surface

Discord is not the source of truth. It is the human control surface over missions, approvals, evidence and status.

## Per OS
- one dedicated bot = Nano Director surface;
- one dedicated home channel;
- one mission = one thread for substantial work;
- child delegation = child mission/thread or typed internal mission reference;
- pinned `/help` explains purpose, commands, permissions and escalation.

## Thread lifecycle
`created → planned → running → review → verified → archived`

The thread summary must include mission ID so the durable mission remains addressable outside Discord.
