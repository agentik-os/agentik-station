# Credential Boundaries

- OS packages contain only credential reference names.
- Personal profiles use personal connection scopes.
- Company/shared OSs use organization-owned connection scopes.
- Client A capability grants can never resolve Client B credential references.
- Agents receive capability tokens/handles, not broad vault dumps.
- Rotation does not require rebuilding the OS package.
