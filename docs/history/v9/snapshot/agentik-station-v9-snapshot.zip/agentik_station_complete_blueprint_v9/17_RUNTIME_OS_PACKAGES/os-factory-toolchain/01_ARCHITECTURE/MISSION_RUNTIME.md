# Mission Runtime

```mermaid
stateDiagram-v2
  [*] --> Proposed
  Proposed --> Planned
  Planned --> Approved
  Approved --> Running
  Running --> Blocked
  Blocked --> Running
  Running --> Review
  Review --> Fix
  Fix --> Running
  Review --> Verified
  Verified --> Completed
  Running --> Failed
  Failed --> Recovery
  Recovery --> Running
  Completed --> [*]
```

Every mission carries:
- mission_id and parent_mission_id;
- organization_id / project_id / os_id;
- initiator and accountable owner;
- goal, acceptance criteria and constraints;
- capability grants;
- knowledge and memory scope;
- credential-reference scope;
- plan and graph;
- evidence pointers;
- state and timestamps.
