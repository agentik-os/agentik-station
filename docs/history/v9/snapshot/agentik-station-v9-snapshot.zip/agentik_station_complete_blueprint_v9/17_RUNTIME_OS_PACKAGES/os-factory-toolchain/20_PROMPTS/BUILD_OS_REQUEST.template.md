# Build OS Request Template

Build a complete AGK Operative System.

## Inputs
- OS name:
- Domain/theme:
- Primary mission:
- Users:
- Organization/client scope:
- Existing tools/data:
- Required outputs/outcomes:
- Constraints/non-goals:
- Risk/approval requirements:

## Mandatory method
Use plan-first, graph loop, Librarian deep research, four owner gates, deterministic tests, verification engineering, independent review, live tests, doctor, rollback/recovery, Discord readback and fresh-session acceptance.

Do not mark the OS complete until every AGK OS Contract component is implemented or explicitly documented as not applicable with an accepted reason.
