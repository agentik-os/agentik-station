# VPS / Agentik Node Deployment Runbook

Recommended build order defined for the AGK stack:
1. backup/export anything that must survive;
2. fresh VPS baseline, OS updates, non-root operator/sudo, SSH hardening;
3. Tailscale/private admin path and firewall policy;
4. container/runtime prerequisites where used;
5. Hermes-only smoke test before adding orchestration layers;
6. Hermes gateway + Discord integration;
7. validate one dedicated profile/bot end to end;
8. project/board/mission execution;
9. worktree/QA/review/evidence path;
10. profiles, distributions, skills and plugins;
11. AGK context/capability router;
12. project systems (e.g. Linear/Notion/memory) as explicit integrations;
13. OS registry/installer;
14. client isolation and credential scopes;
15. lockfile, updates, rollback, doctor and recovery;
16. end-to-end/fresh-session acceptance.

Do not install every subsystem before proving the runtime foundation.
