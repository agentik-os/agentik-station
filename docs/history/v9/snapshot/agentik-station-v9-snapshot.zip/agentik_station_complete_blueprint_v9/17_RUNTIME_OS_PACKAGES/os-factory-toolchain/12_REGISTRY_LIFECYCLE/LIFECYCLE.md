# OS Lifecycle

`draft → researched → specified → gated → built → reviewed → packaged → staged → accepted → released → observed → upgraded/deprecated`

## Install
Resolve package + dependencies → verify checksums/signature policy → apply config bindings → bind credential references → register capabilities/workflows/automations → configure Discord → doctor → live probes → fresh-session acceptance.

## Update
Create new immutable version. Never silently mutate an installed version. Use dependency lock and migration plan.

## Fork
Private fork keeps upstream ancestry metadata. Upgrade/merge requires explicit conflict handling for contract, programs, workflows, evals and knowledge.

## Uninstall
Disable automations/side effects → archive missions → export required evidence/data according to policy → unbind credentials → unregister capabilities → remove active package reference.
