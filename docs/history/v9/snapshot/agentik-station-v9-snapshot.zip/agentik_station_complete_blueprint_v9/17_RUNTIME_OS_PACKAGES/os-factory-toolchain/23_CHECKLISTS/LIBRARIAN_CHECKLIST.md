# Librarian Checklist

- [ ] Research mission contextualized
- [ ] Query/research map built
- [ ] Canonical/foundational lane searched
- [ ] Primary/official lane searched
- [ ] Applied/operator lane searched
- [ ] Current sources added where domain is time-sensitive
- [ ] Competing schools captured
- [ ] Provenance verified
- [ ] No invented citations/quotes
- [ ] Principles synthesized in original language
- [ ] Candidate inputs deduplicated
- [ ] Exactly 15 best inputs selected
- [ ] Each input mapped to OS components
- [ ] Evals/doctor/recovery implications present
- [ ] Uncertainty and contradictions stated
- [ ] `14_BUILDER_HANDOFF.md` produced
- [ ] Machine-readable source packet produced
