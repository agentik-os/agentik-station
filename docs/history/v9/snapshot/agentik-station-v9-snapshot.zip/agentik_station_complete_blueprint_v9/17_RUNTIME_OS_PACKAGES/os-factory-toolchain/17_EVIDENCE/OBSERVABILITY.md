# Evidence & Observability

Evidence types:
- plan snapshot;
- graph snapshot;
- Librarian packet checksum;
- test report;
- eval report;
- tool live-probe result;
- doctor report;
- security review;
- Discord readback;
- fresh-session transcript/result;
- package checksum;
- rollback/recovery test;
- release decision.

The goal is not maximal logging. The goal is enough durable evidence to explain what happened, prove acceptance and recover safely.
