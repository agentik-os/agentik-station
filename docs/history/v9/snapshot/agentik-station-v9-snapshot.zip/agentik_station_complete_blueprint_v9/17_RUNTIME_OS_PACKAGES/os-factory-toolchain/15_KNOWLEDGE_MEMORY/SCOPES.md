# Knowledge and Memory Scopes

## Knowledge
Curated sources an OS is allowed to retrieve. Each source has provenance, owner, scope, freshness and write/update policy.

## Memory
Durable learned/user/mission state. Declare:
- namespace;
- tenant/project/OS/profile scope;
- read actors;
- write actors;
- retention/expiry;
- provenance;
- sensitivity;
- deletion path.

Do not use “shared memory” as a shortcut across client or personal/company boundaries.
