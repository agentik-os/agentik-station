# Recursive OS Model

An OS may contain internal domain OSs or call external OS capabilities, but recursion must remain governed.

Rules:
- child OS receives the minimum required capability grant;
- no implicit credential inheritance;
- no implicit memory inheritance;
- parent mission ID is preserved;
- typed input/output contracts are mandatory at OS boundaries;
- recursion depth and concurrency are runtime policy, not prompt convention;
- evidence rolls up from child missions to the parent mission.
