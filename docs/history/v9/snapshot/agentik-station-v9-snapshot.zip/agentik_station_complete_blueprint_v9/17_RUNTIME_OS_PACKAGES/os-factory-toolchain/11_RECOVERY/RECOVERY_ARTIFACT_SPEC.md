# Recovery Artifact

A recovery artifact must be sufficient to reconstruct operational behavior while containing no secret values.

Include:
- OS immutable package or exact package locator/checksum;
- manifest and contract;
- dependency lock;
- config schema + non-secret config snapshot;
- data backup locator/instructions;
- credential reference list;
- restore procedure;
- doctor procedure;
- fresh-session critical-path procedure;
- Discord readback procedure;
- known-good evidence pointers.
