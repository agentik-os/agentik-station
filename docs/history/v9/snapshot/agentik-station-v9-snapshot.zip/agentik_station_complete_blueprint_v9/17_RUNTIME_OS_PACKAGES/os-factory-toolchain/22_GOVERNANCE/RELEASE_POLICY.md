# Release Policy

No release when any of the following is true:
- Librarian handoff incomplete or sources unverified;
- fewer than 15 selected inputs without explicit owner exception;
- critical requirement lacks verification;
- doctor failure;
- unresolved critical independent-review finding;
- secret embedded in package;
- tenant-isolation failure;
- critical integration not live-tested;
- Discord surface unreadable/unreachable for a Discord-controlled OS;
- fresh-session critical path fails;
- recovery artifact missing.
