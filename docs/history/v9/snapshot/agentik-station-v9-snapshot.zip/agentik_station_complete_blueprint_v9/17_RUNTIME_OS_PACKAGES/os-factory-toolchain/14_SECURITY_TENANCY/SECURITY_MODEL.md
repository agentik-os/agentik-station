# Security & Tenancy Model

## Default-deny boundaries
Organization → client/project → OS → profile → mission → capability.

## Principles
- one client cannot see another client's agents, missions, memory or credentials;
- capability grants are explicit and minimal;
- secret values are injected only at execution boundary;
- destructive and external side effects follow approval policy;
- package artifacts are safe to inspect/share within their distribution class;
- evidence is redacted and scoped;
- logs never become an accidental memory or secret store.
