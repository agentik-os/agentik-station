# Canonical Command Catalog

- `/mission` create mission + thread.
- `/plan` show plan, graph and acceptance.
- `/status` current state, blockers, next action, evidence.
- `/delegate` create typed child mission.
- `/approve` record explicit gate/side-effect approval.
- `/review` dispatch independent review.
- `/evidence` show verification artifacts.
- `/doctor` run health checks.
- `/rollback` propose or execute governed rollback according to permissions.
- `/recover` start recovery workflow.
- `/install` install an OS package into allowed scope.
- `/upgrade` stage OS upgrade.
- `/help` dedicated OS help.

Domain OSs add domain commands; they do not remove mission governance.
