# System Architecture

```mermaid
flowchart TB
  User[Human / Event / API / Discord]
  CP[AGK Control Plane]
  Org[Organization Scope]
  Reg[OS Registry + Lockfile]
  Hermes[Hermes Runtime]
  Router[Context + Capability Router]
  OS1[OS A]
  OS2[OS B]
  Evidence[Evidence / Evals / Observability]
  Data[(Scoped Durable Data)]
  Secrets[Credential References]
  Tools[MCP · Composio · APIs]

  User --> CP
  CP --> Org
  Org --> Reg
  Org --> Hermes
  Hermes --> Router
  Router --> OS1
  Router --> OS2
  OS1 --> Tools
  OS2 --> Tools
  OS1 --> Data
  OS2 --> Data
  OS1 --> Secrets
  OS2 --> Secrets
  OS1 --> Evidence
  OS2 --> Evidence
```

## Ownership

| Layer | Owns |
|---|---|
| Agentik | UX, marketplace, install/configuration experience, workspace |
| AGK | standards, packages, governance, graph, permissions, composition, lifecycle |
| Hermes | agent execution, tool invocation, delegation, session runtime |
| OS | domain behavior, NanoTeam, programs, workflows, evals, Discord surface |
| Organization | data/credential tenancy and policy |
