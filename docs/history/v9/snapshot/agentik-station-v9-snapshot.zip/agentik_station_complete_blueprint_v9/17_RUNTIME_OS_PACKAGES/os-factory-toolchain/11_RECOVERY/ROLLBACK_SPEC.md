# Rollback Specification

Prefer immutable package activation rather than editing a broken release in place.

Rollback bundle records:
- current version;
- previous known-good version;
- package checksum;
- config snapshot reference;
- migration state;
- reversible vs forward-only data changes;
- secret reference names;
- post-rollback doctor and acceptance commands.
