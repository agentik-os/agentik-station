# 20_VIEWS

Required AGK OS v2 component. Replace this placeholder with the OS-specific contract/artifacts.
