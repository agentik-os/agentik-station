# Post-Install Discord Bootstrap

## User experience

After the Node reaches `READY_UNBOUND`:

```bash
agentik discord connect
```

The user adds/authorizes the Agentik Discord application on the intended server.

Then:

```bash
agentik discord plan
agentik discord apply
agentik discord verify
agentik doctor
```

The final product may combine these into a guided UI, but these primitives should remain independently testable.

## What the Bootstrap Director sets up

- system and human roles declared by policy
- role hierarchy checks
- categories from organization macro domains / OS surfaces
- channels from OS surface manifests
- category/channel permission overwrites
- channel topics/pins where configured
- slash-command scopes/visibility where supported
- mission-capable thread policies
- OS/team/director/project/board bindings
- system channels for health/evidence/incidents
- runtime bot role

## What it does NOT do by default

- delete unknown existing channels
- delete unknown roles
- move/rename unmanaged resources arbitrarily
- grant every AI worker Discord membership
- keep Administrator forever
- use channel names as the only routing source

## Linking teams

Each exposed channel ends with a runtime binding:

```text
channel_id
→ organization
→ OS
→ Director profile
→ Project
→ Kanban Board
→ capability policy
```

Cross-team work uses AGK/Hermes internal team contracts rather than needing one bot per team.

## Final verification

Bootstrap is complete only when:

```text
all required resources exist
+ bindings resolve
+ route smoke tests pass
+ runtime bot is demoted from Administrator
+ doctor is green
```
