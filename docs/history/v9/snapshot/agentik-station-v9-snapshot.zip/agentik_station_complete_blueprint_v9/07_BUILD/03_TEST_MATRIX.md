# Test Matrix

| Area | Test |
|---|---|
| Hermes | provider response |
| Gateway | restart + persistence |
| Ponytail | plugin installed/enabled when DevOps OS selected |
| Ponytail | review skill executes in engineering review |
| Discord Connect | correct target guild bound |
| Discord Bootstrap | inventory captures roles/categories/channels |
| Discord Bootstrap | first plan is deterministic |
| Discord Bootstrap | apply creates/adopts required resources |
| Discord Bootstrap | second apply produces no duplicates |
| Discord Safety | unknown channel not deleted by default |
| Discord Safety | Administrator removed after verify |
| Discord Hierarchy | bot cannot manage roles at/above itself |
| Discord Binding | every managed OS channel has immutable ID binding |
| Discord Binding | channel rename preserves routing |
| Discord Routing | DevOps channel reaches DevOps Director |
| Discord Routing | wrong/ambiguous binding blocks sensitive action |
| Discord Drift | manual managed change detected |
| Thread/Session | thread A cannot leak thread B history |
| Mission | thread may remain conversational without mission |
| Mission | durable request creates root Kanban task |
| Profiles | profile A memory separated from B |
| Credentials | profile cannot access unscoped secret |
| Project | correct repo context |
| Board | task only visible in correct board |
| Delegation | fresh child context |
| Worktree | parallel changes isolated |
| Goal | red gate prevents completion |
| Review | reviewer can request changes |
| Checkpoint | rollback restores agent change |
| Linear | root issue sync where configured |
| Notion | knowledge writes to correct org |
| Memory | candidate saved to correct namespace |
| Evidence | mission + bootstrap output have proof |
| Backup | off-node artifact produced |
| Restore | clean Node restored |
| Update | failed candidate rolls back |
| Client isolation | cross-client secret inaccessible |

| Engineering | complex mission produces typed Loop-Graph before execution |
| Engineering | graph retry loops are bounded |
| Verification | code edit cannot complete without required fresh evidence |
| Verification | failed mandatory gate blocks completion |
| Gauntlet | implementer cannot self-approve final artifact |
| Gauntlet | fresh critic can reject and route targeted retry |
| Gauntlet | exhausted pass budget escalates instead of looping forever |
| Subagents | delegated task has explicit ownership/output/verification contract |
| Parallel | overlapping mutable ownership is rejected or serialized |
| Worktrees | concurrent writers get isolated branches/worktrees |
| Worktrees | Discord thread with no code does not create worktree |
| Integration | fan-in reruns integration verification |
| Model routing | OS works after swapping route to alternate provider:model |
| Model routing | critical route fallback works without workflow rewrite |
| Logs | Hermes native log references are attached to episode index |
| Evidence | engineering episode reconstructs spec→graph→diff→verify→critic→deploy |
| Learning | shared skill candidate requires configured promotion gate |
| Learning | security/capability policy cannot self-weaken through learning loop |
| Ponytail | simplification review occurs before merge |
