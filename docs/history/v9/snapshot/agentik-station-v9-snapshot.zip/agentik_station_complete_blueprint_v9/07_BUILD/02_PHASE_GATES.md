# Phase Gates

## Gate 0 — Safe to reset
- repos pushed
- state backed up
- secrets outside Git
- important data exported

## Gate 1 — Hermes works
- provider response
- one direct conversation

## Gate 2 — Persistent runtime healthy
- gateway healthy
- doctor/security baseline acceptable

## Gate 3 — Organization + OS desired state works
- organization parsed
- profiles installed
- Projects/Boards created
- DevOps OS installs Ponytail when selected

## Gate 4 — Discord connection works
- bot/application added to intended server
- gateway online
- target guild identity confirmed

## Gate 5 — Discord bootstrap works
- Bootstrap Director inventory succeeds
- plan generated
- roles/categories/channels created/adopted
- repeated apply is idempotent
- no unmanaged resource deleted

## Gate 6 — Team binding works
- every exposed OS channel has immutable binding
- channel → correct Director/Project/Board
- channel rename does not break route

## Gate 7 — Runtime privilege downgrade works
- Administrator removed
- runtime operations still work
- role hierarchy safe

## Gate 8 — Delegation works
- Director delegates
- child context isolated
- synthesis returns

## Gate 9 — Project execution works
- root mission task
- task graph
- worktree
- tests

## Gate 10 — Independent review works
- implementer cannot be sole approver
- request-changes returns to execution
- Ponytail review active for DevOps work

## Gate 11 — Complete E2E works
- Discord through mission/evidence/integrations

## Gate 12 — Isolation works
- Org A cannot access Org B

## Gate 13 — Rebuild + rebootstrap works
- fresh VPS restore succeeds
- Discord reconcile converges without duplication
