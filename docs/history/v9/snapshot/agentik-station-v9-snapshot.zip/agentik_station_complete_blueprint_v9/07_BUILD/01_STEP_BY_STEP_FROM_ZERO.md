# Step-by-Step: Zero → Operational Station

## Phase 0 — Prepare desired state
1. choose Station ID and mode (`owner` or `client`);
2. define trust zones / organization / projects;
3. define external secret namespaces;
4. define Discord server and OS bot enrollment plan;
5. create initial `agentik.lock`/Station lock.

## Phase 1 — Host baseline
1. fresh supported Linux VPS;
2. `station-admin` sudo account + SSH keys;
3. updates, Tailscale, firewall, fail2ban/equivalent;
4. storage/log/backup prerequisites.

## Phase 2 — Trust zones
Create `station-system`, `gareth-private`, `gareth-projects`, `agentik-dev`, `os-factory`, `station-lab` users/homes/roots for owner Station. Client Stations use a smaller organization-specific layout.

## Phase 3 — LAB Hermes first
Install Hermes into LAB, no production credentials. Run smoke + `hermes doctor`.

## Phase 4 — Station policy
Install context injector + fail-closed pre-tool guard; pin security baseline; run `hermes hooks doctor` and synthetic allow/deny tests.

## Phase 5 — Stable Hermes release
After LAB pass, pin exact approved Hermes commit in Station lock and install stable zone runtimes.

## Phase 6 — System OSs
Install Station Maintainer → Discord Bootstrap → Librarian → Builder → DevOps/Ponytail.

## Phase 7 — Imported factory pack tests
Run integrated Builder/Librarian deterministic test suite and pack doctor.

## Phase 8 — Organization/projects
Create project descriptors, boards, profiles, capability/credential/memory namespaces and allowed roots.

## Phase 9 — Discord bootstrap
Authorize bootstrap integration temporarily, plan/diff/apply server structure, enroll/bind dedicated OS bot credentials, sync commands, verify readback, remove Administrator.

## Phase 10 — Engineering/recovery
Run canonical mission, worktree/parallel test, Doctor, backup, rollback/recovery drill and fresh-session acceptance.

## Phase 11 — Hermes updater watchdog
Install/enable `station-hermes-watch.timer`; verify an upstream-check event can be recorded without mutating stable runtime.

## Phase 12 — Operational
Create Station release/evidence receipt and mark Node operational only when every hard gate passes.


## Composio adapter availability
After Hermes/Station core is healthy, install the Composio CLI with `scripts/install_composio_cli.sh`. Do not perform global shared account linking. Onboard Composio credentials and connected accounts separately inside the intended trust zone/Node, then run OS Doctor and fresh-session acceptance for each external capability.
