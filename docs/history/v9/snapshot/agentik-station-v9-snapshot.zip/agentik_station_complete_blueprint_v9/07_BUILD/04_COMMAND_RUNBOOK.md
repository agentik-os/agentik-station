# VPS Command Runbook

This is an implementation runbook, not a substitute for reviewing current official install documentation.

Version-sensitive commands should be revalidated before execution.

---

# 1. Fresh Ubuntu

Connect:

```bash
ssh root@SERVER_IP
```

Update:

```bash
apt update
apt upgrade -y
```

Base tools:

```bash
apt install -y \
  git \
  curl \
  wget \
  jq \
  unzip \
  ca-certificates \
  gnupg \
  ufw \
  fail2ban \
  htop \
  tmux
```

---

# 2. Create admin user

Example:

```bash
adduser gareth
usermod -aG sudo gareth
```

SSH key:

```bash
mkdir -p /home/gareth/.ssh
nano /home/gareth/.ssh/authorized_keys

chmod 700 /home/gareth/.ssh
chmod 600 /home/gareth/.ssh/authorized_keys
chown -R gareth:gareth /home/gareth/.ssh
```

Open a second terminal and verify:

```bash
ssh gareth@SERVER_IP
```

Do not continue until it works.

---

# 3. Tailscale

Install using the current official Linux method.

Typical flow:

```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```

Verify:

```bash
tailscale status
tailscale ip -4
```

Then verify SSH through Tailscale.

---

# 4. Firewall

Initial safe configuration:

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw allow in on tailscale0
sudo ufw enable
sudo ufw status verbose
```

Do not remove public SSH access until private access is proven.

---

# 5. Docker

Install Docker Engine and Compose through the current official Docker Ubuntu repository.

After install:

```bash
sudo docker run hello-world
docker compose version
```

---

# 6. Agentik filesystem

```bash
sudo mkdir -p /opt/agentik-node

sudo mkdir -p /srv/agentik/projects
sudo mkdir -p /srv/agentik/os
sudo mkdir -p /srv/agentik/capabilities

sudo mkdir -p /var/lib/agentik/hermes
sudo mkdir -p /var/lib/agentik/memory
sudo mkdir -p /var/lib/agentik/data
sudo mkdir -p /var/lib/agentik/evidence

sudo mkdir -p /var/log/agentik
sudo mkdir -p /var/backups/agentik
```

---

# 7. Clone Agentik Node

```bash
sudo git clone \
  https://github.com/agentik-os/agentik-node.git \
  /opt/agentik-node
```

If the repo does not exist yet, create it first locally/GitHub.

---

# 8. Hermes first-run setup

Using the official Hermes Docker image:

```bash
sudo docker run -it --rm \
  -v /var/lib/agentik/hermes:/opt/data \
  nousresearch/hermes-agent setup
```

Configure one model provider.

---

# 9. Hermes smoke test

Run interactive Hermes against same state volume.

```bash
sudo docker run -it --rm \
  -v /var/lib/agentik/hermes:/opt/data \
  nousresearch/hermes-agent
```

Test:

```text
Reply exactly: HERMES_OK
```

Gate:
do not continue until this works.

---

# 10. Persistent Hermes Compose

Create:

```text
/opt/agentik-node/compose/core.yaml
```

using `06_CONFIG/docker-compose.core.example.yaml`.

Start:

```bash
cd /opt/agentik-node

sudo docker compose \
  -f compose/core.yaml \
  up -d
```

Inspect:

```bash
sudo docker ps
sudo docker logs --tail 100 hermes
```

---

# 11. Hermes wrapper

Create:

```bash
sudo nano /usr/local/bin/hx
```

Content:

```bash
#!/usr/bin/env bash
docker exec -it hermes hermes "$@"
```

Then:

```bash
sudo chmod +x /usr/local/bin/hx
```

Examples:

```bash
sudo hx status
sudo hx doctor
sudo hx security audit
```

---

# 12. Dashboard through SSH tunnel

On local machine:

```bash
ssh -L 9119:127.0.0.1:9119 gareth@TAILSCALE_IP
```

Then:

```text
http://127.0.0.1:9119
```

Do not expose the dashboard directly to the public Internet.

---

# 13. Profile

Create first persistent Director:

```bash
sudo hx profile create devops-director
sudo hx profile list
sudo hx profile show devops-director
```

Configure its SOUL separately.

---

# 14. Sandbox project

```bash
sudo mkdir -p /srv/agentik/projects/sandbox

sudo git clone \
  https://github.com/agentik-os/agentik-node-sandbox.git \
  /srv/agentik/projects/sandbox
```

Add `AGENTS.md`.

---

# 15. Hermes Project

Use the current Hermes project CLI to:

```text
create project: agentik-sandbox
add folder: /workspace/projects/sandbox
```

Verify:

```bash
sudo hx project list
sudo hx project show agentik-sandbox
```

---

# 16. Board

Create:

```bash
sudo hx kanban boards create agentik-sandbox \
  --name "Agentik Sandbox"
```

Verify:

```bash
sudo hx kanban boards list
```

Bind Project ↔ Board using current Hermes CLI.

---

# 17. Mission

Create a simple mission:

```text
Add GET /health returning {"status":"ok"} and automated tests.
```

Use goal mode where supported.

---

# 18. Reviewer

Create:

```bash
sudo hx profile create reviewer
```

Its role:
- no primary implementation
- verify acceptance criteria
- approve/request changes

---

# 19. Distribution

Once DevOps Director is proven:

```text
publish director-devops as a Profile Distribution
```

Then test a fresh install under another local profile name.

---

# 20. Build order after that

```text
skills
→ Ponytail
→ agentik-control
→ context resolution + binding registry
→ Linear
→ Notion
→ agentik-memory
→ OS Registry
→ DevOps OS
→ full E2E
→ doctor
→ installer
→ Gareth organization
→ fake client
→ client Node
→ lockfile
→ update CI
→ backup
→ disaster recovery
```

---

# Safety rule

Never paste secrets into:
- Git
- issue trackers
- docs
- public Discord
- this runbook

Use secret references and an external secret source.

# 21. Install Ponytail for DevOps OS

```bash
sudo hx plugins install DietrichGebert/ponytail --enable
```

Restart the Hermes service/gateway according to the deployed service manager.

Verify the plugin and its skills before marking DevOps OS healthy.

---

# 22. Discord connect + bootstrap (target CLI contract)

```bash
sudo agentik discord connect
sudo agentik discord status
sudo agentik discord plan
sudo agentik discord apply
sudo agentik discord verify
```

Expected flow:

```text
connect target guild
→ authorize bootstrap
→ plan current vs desired
→ apply safe changes
→ verify bindings
→ demote bootstrap Administrator
```

Never put the Discord bot token in the config repository.

---

# 23. Reconcile after installing an OS

```bash
sudo agentik os install agk.devops
sudo agentik apply
sudo agentik discord plan
sudo agentik discord apply
sudo agentik doctor
```

A second `discord plan` should be empty or contain only accepted drift.

## Engineering Harness checks

Representative Hermes-native commands/configuration to verify during implementation:

```bash
hermes logs list
hermes logs agent -n 100
hermes worktree list
hermes worktree prune --dry-run
```

Ponytail:

```bash
hermes plugins install DietrichGebert/ponytail --enable
```

Actual config values MUST be read from the pinned Hermes version/documentation during implementation; `agentik.lock` records the tested runtime/plugin revisions.
