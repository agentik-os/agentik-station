# Builder + Librarian Ready-to-Build Path

```bash
cd 17_RUNTIME_OS_PACKAGES/os-factory-toolchain
python3 tests/run_tests.py
python3 programs/agk_builder.py doctor-pack
```

At runtime these programs are staged under the `os-factory` trust zone. Generated OS candidates stay in factory staging until contract, Doctor, Discord, fresh-session, recovery and release gates pass.
