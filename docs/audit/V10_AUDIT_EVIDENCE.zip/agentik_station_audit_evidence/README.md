# Agentik Station Audit Evidence

This bundle contains local command outputs used during the 2026-09-03 professional audit:

- `baseline_tests.txt`: current repo Doctor, unit/factory tests and Python compile;
- `critical_reproductions.txt`: safe dry-run reproductions of plan mismatch, path traversal and remote command injection;
- `systemd_verify.txt`: `systemd-analyze verify` output;
- `repo_metrics.txt`: file, cache, duplication and OS package metrics;
- `os_contract_doctor.txt`: the repository's own AGK OS Doctor against every bundled OS package.

No real remote Host was contacted and no real VPS was modified.
